//package vn.com.vds.junit;
//
//import org.junit.platform.runner.JUnitPlatform;
//import org.junit.platform.suite.api.SelectClasses;
//import org.junit.runner.RunWith;
//import vn.com.vds.model.UserService;
//
//@RunWith(JUnitPlatform.class)
//@SelectClasses({AssertionsDemo.class, UserService.class})
//public class AssertionsTestAndUserServiceMockitoTest {
//}
