package accessmodifiers;

public class Human {
    private Long id;
    protected String name;
    Integer age;
    public String kind;
}
