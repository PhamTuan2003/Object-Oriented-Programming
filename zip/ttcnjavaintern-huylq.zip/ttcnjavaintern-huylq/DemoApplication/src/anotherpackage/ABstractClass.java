package anotherpackage;

public abstract class ABstractClass {
    void fly(){

    }
}
