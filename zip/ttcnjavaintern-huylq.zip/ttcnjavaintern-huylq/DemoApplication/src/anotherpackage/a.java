package anotherpackage;

public class a implements Aasdfg {
}
