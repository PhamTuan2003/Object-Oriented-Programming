package anotherpackage;

import accessmodifiers.ClassPresident;
import accessmodifiers.Student;

public class VicePresident extends Student {
    void method() {

    }
}
