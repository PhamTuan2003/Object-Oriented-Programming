package anotherpackage;

public interface Aasdfg {
    default void fly(){

    }

}
