package test;

public class Mammal {
    public String name;
    public Mammal(int age) {
        System.out.println("Mammal");
    }
    public void print() {
        System.out.println("Mammal");
    }
}
