package behavioral.cor.builder;

public interface Builder {
}
